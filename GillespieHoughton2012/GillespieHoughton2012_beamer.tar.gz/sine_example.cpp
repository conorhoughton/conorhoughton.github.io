#include<cstdlib>
#include<iostream>
#include<cmath>
#include<vector>

using namespace std;

int main()
{

  double dx=0.01;

  double pi=4*atan(1);

  int trial_n=10;
  
  vector<vector<double> > signals;

  double a=0.2;

  for(unsigned int i=0;i<trial_n ;++i)
    {
      vector<double> this_signal;
      double this_a=a*double(rand())/double(RAND_MAX);
      double this_phi=2*pi*double(rand())/double(RAND_MAX);
      for(double x=0;x<=2*pi;x+=dx)
	this_signal.push_back(sin(x)+this_a*sin(4*x+this_phi));
      signals.push_back(this_signal);
    }

  vector<double> average;


  for(unsigned int j=0;j<signals[0].size() ;++j)
    {
      double value=0;
      for(unsigned int i=0;i<trial_n ;++i)
	value+=signals[i][j];
      average.push_back(value/trial_n);
    }



  for(unsigned int j=0;j<signals[0].size() ;++j)
    {
      cout<<j*dx<<" ";
      for(unsigned int i=0;i<trial_n ;++i)
	cout<<signals[i][j]<<" ";
      cout<<average[j]<<endl;
    }

}
